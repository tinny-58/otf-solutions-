# OTF Solutions — WhatsApp Agent Backend

## Quick Start (your server)

```bash
# 1. Install dependencies
npm install

# 2. Create your .env from the template
cp .env.example .env
nano .env          # fill in ALL keys

# 3. Start (development)
npm run dev

# 4. Start (production with PM2)
npm install -g pm2
pm2 start server.js --name otf-agent
pm2 save && pm2 startup
```

## File Structure

```
otf-agent/
├── server.js           ← Backend — ALL API keys live here only
├── .env                ← Your secrets — NEVER commit to git
├── .env.example        ← Template (safe to commit)
├── .gitignore
├── package.json
└── public/
    ├── index.html      ← Your OTF website (served at /)
    └── agent.html      ← Agent dashboard (served at /agent.html)
```

## API Endpoints

| Route | Auth | Purpose |
|-------|------|---------|
| `GET  /api/health` | public | Server + service status |
| `POST /api/simulate` | public | Simulate a client message |
| `POST /api/webhook/twilio` | Twilio | Inbound WhatsApp messages |
| `POST /api/webhook/forward` | public | Forward to Make.com |
| `GET  /api/stats/public` | public | Message counts (no PII) |
| `GET  /api/admin/logs` | `X-Admin-Secret` | Full conversation logs |
| `GET  /api/admin/export` | `X-Admin-Secret` | Download logs as JSON |

## Security Model

- **API keys (Anthropic, Twilio)** — server-side only, in `.env`, never sent to browser
- **Admin routes** — protected by `X-Admin-Secret` header (only you know it)
- **Rate limiting** — 30 req/min on API, 100 req/min on webhooks
- **Helmet** — security headers on every response
- **Input sanitization** — all inbound text filtered before AI call

## Twilio Webhook Setup

In Twilio Console → Messaging → WhatsApp Senders → your number → edit:
- **When a message comes in**: `https://yourdomain.com/api/webhook/twilio`
- Method: `HTTP POST`

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | ✅ | Claude AI key |
| `TWILIO_ACCOUNT_SID` | ✅ | Twilio account |
| `TWILIO_AUTH_TOKEN` | ✅ | Twilio auth |
| `TWILIO_FROM_NUMBER` | ✅ | WhatsApp sender number |
| `MAKE_WEBHOOK_URL` | ✅ | Make.com webhook |
| `OWNER_WHATSAPP` | ✅ | Your WhatsApp for alerts |
| `ADMIN_SECRET` | ✅ | Protects /api/admin/* |
| `PORT` | optional | Default: 3000 |

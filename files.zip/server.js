/**
 * OTF Solutions — WhatsApp Agent Backend
 * ----------------------------------------
 * All API keys live here — NEVER in the browser.
 * Run: node server.js (or pm2 start server.js --name otf-agent)
 *
 * Env vars required (set in .env — DO NOT commit .env to git):
 *   OPENAI_API_KEY=sk-...          ← OpenAI key (gpt-4o-mini)
 *   TWILIO_ACCOUNT_SID=ACxxxxxxxx
 *   TWILIO_AUTH_TOKEN=xxxxxxxx
 *   TWILIO_FROM_NUMBER=whatsapp:+14155238886
 *   MAKE_WEBHOOK_URL=https://hook.eu1.make.com/kjs46hr0s5bv3rdcbrxh8v8anmrwhya1
 *   OWNER_WHATSAPP=whatsapp:+254106351077
 *   ADMIN_SECRET=your-strong-random-string   ← protects /api/admin routes
 *   PORT=3000
 */

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

const app = express();

/* ── SECURITY MIDDLEWARE ── */
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ── RATE LIMITS ── */
const apiLimiter = rateLimit({ windowMs: 60_000, max: 30, message: { error: 'Too many requests' } });
const webhookLimiter = rateLimit({ windowMs: 60_000, max: 100, message: { error: 'Rate limit' } });

/* ── STATIC FILES (your website) ── */
app.use(express.static(path.join(__dirname, 'public')));

/* ── ADMIN AUTH MIDDLEWARE ── */
function adminOnly(req, res, next) {
  const token = req.headers['x-admin-secret'] || req.query.secret;
  if (!token || token !== process.env.ADMIN_SECRET) {
    return res.status(403).json({ error: 'Forbidden — owner access only' });
  }
  next();
}

/* ═══════════════════════════════════════════════
   IN-MEMORY CONVERSATION STORE
   (replace with SQLite/Postgres for production)
═══════════════════════════════════════════════ */
const store = {
  conversations: [],     // all conversation records
  sessions: new Map(),   // phone → last 6 messages (multi-turn memory)

  addRecord(record) {
    this.conversations.unshift({ id: Date.now(), ...record });
    if (this.conversations.length > 500) this.conversations.length = 500;
  },

  getSession(phone) {
    return this.sessions.get(phone) || [];
  },

  updateSession(phone, userMsg, assistantMsg) {
    const history = this.getSession(phone);
    history.push({ role: 'user', content: userMsg });
    history.push({ role: 'assistant', content: assistantMsg });
    if (history.length > 12) history.splice(0, 2); // keep last 6 turns
    this.sessions.set(phone, history);
  },

  getStats() {
    const total  = this.conversations.length;
    const spam   = this.conversations.filter(c => c.spam).length;
    const legit  = total - spam;
    const unique = new Set(this.conversations.map(c => c.from)).size;
    return { total, spam, legit, unique };
  }
};

/* ═══════════════════════════════════════════════
   SPAM DETECTION ENGINE
═══════════════════════════════════════════════ */
const SPAM_PATTERNS = [
  /click here to win/i, /you have been selected/i, /send money/i,
  /crypto investment/i, /free gift/i, /urgent transfer/i,
  /double your money/i, /act now/i, /limited time offer/i,
  /binary trading/i, /forex signal/i, /make money fast/i,
  /prize winner/i, /claim your reward/i, /investment opportunity/i,
  /bank account details/i, /western union/i, /m-pesa scam/i,
];

function detectSpam(text) {
  if (!text || text.trim().length < 2) return { isSpam: true, reason: 'empty or too short' };
  if (text.length > 2000)              return { isSpam: true, reason: 'message too long' };
  const urlCount = (text.match(/https?:\/\//g) || []).length;
  if (urlCount > 2)                    return { isSpam: true, reason: 'too many URLs' };
  for (const pat of SPAM_PATTERNS) {
    if (pat.test(text)) return { isSpam: true, reason: `matched pattern: ${pat.source}` };
  }
  return { isSpam: false };
}

/* ═══════════════════════════════════════════════
   TWILIO HELPER
═══════════════════════════════════════════════ */
async function sendWhatsApp(to, body) {
  const { TWILIO_ACCOUNT_SID: sid, TWILIO_AUTH_TOKEN: token, TWILIO_FROM_NUMBER: from } = process.env;
  if (!sid || !token || !from) {
    console.warn('[Twilio] Missing credentials — message not sent');
    return { skipped: true };
  }
  const url  = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
  const cred = Buffer.from(`${sid}:${token}`).toString('base64');
  const params = new URLSearchParams({ From: from, To: to, Body: body });

  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Basic ${cred}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString()
  });
  return res.json();
}

/* ═══════════════════════════════════════════════
   OPENAI gpt-4o-mini HELPER — research + OTF knowledge
═══════════════════════════════════════════════ */
const OTF_SYSTEM_PROMPT = `You are the intelligent WhatsApp business agent for OTF Solutions Ltd — Kenya's premier digital solutions company based in Nairobi.

OTF SOLUTIONS — FULL SERVICE CATALOGUE:
• Custom workflow automation (Make.com, Zapier, n8n, Power Automate)
• AI-powered WhatsApp agents and chatbots
• Professional web design and e-commerce development
• AI content detection and plagiarism removal services
• KRA tax filing and compliance assistance
• Bulk SMS marketing campaigns
• API integrations and system connectivity
• Data dashboards and analytics
• CRM setup (HubSpot, Airtable, Notion)
• IT consulting and digital transformation advisory
• Training and capacity building for business teams

CONTACT: otfsolutionsltd@gmail.com | 0106351077 | WhatsApp: 0106351077

BEHAVIOUR RULES:
1. ANALYZE deeply before answering — understand the client's industry, pain point, and true need.
2. Use research-backed reasoning: explain WHY a solution fits their context.
3. WhatsApp style: concise, warm, professional. No markdown, no bullet points. Short natural paragraphs, max 3-4 sentences.
4. Never quote specific prices — say "pricing depends on scope, our team will send a tailored quote."
5. If complex, offer a free consultation call or demo.
6. Greet by name when available. End with a helpful question or next step.
7. You represent OTF Solutions' founder vision: smart, affordable, locally relevant tech for Kenyan businesses.
8. One emoji max per message, only when genuinely appropriate.`;

async function callOpenAI(clientName, fromNumber, message, sessionHistory) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error('OPENAI_API_KEY not configured');

  // Build messages: system prompt + session history + new user turn
  const messages = [
    { role: 'system', content: OTF_SYSTEM_PROMPT },
    ...sessionHistory,
    {
      role: 'user',
      content: `Client name: ${clientName || 'valued client'}\nClient WhatsApp: ${fromNumber}\nMessage: ${message}\n\nAnalyze this message carefully. Determine what OTF Solutions service best addresses their need — and why. Then compose a helpful, researched WhatsApp reply.`
    }
  ];

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      max_tokens: 600,
      temperature: 0.65,
      messages
    })
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenAI API error ${res.status}: ${err}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim()
    || 'Thank you for reaching out to OTF Solutions. Our team will be in touch shortly.';
}

/* ═══════════════════════════════════════════════
   ROUTES
═══════════════════════════════════════════════ */

/* ── Health check ── */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    agent: 'OTF Solutions WhatsApp Agent v1.0',
    timestamp: new Date().toISOString(),
    services: {
      openai:    !!process.env.OPENAI_API_KEY,
      twilio:    !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN),
      makeWebhook: !!process.env.MAKE_WEBHOOK_URL
    }
  });
});

/* ── PUBLIC: forward message to Make.com webhook (triggered by your website) ── */
app.post('/api/webhook/forward', webhookLimiter, async (req, res) => {
  try {
    const { from, profileName, body: msgBody, messageSid } = req.body;
    if (!from || !msgBody) return res.status(400).json({ error: 'Missing from or body' });

    const makeUrl = process.env.MAKE_WEBHOOK_URL;
    if (makeUrl) {
      await fetch(makeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ From: from, ProfileName: profileName, Body: msgBody, MessageSid: messageSid })
      });
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ── MAIN: Twilio inbound webhook (Twilio POSTs here) ── */
app.post('/api/webhook/twilio', webhookLimiter, async (req, res) => {
  const { From, ProfileName, Body: msgBody, MessageSid } = req.body;

  // Always respond 200 to Twilio immediately
  res.set('Content-Type', 'text/xml');
  res.send('<Response></Response>');

  if (!From || !msgBody) return;

  const record = {
    id:         MessageSid || `msg_${Date.now()}`,
    from:       From,
    clientName: ProfileName || 'Unknown',
    message:    msgBody,
    timestamp:  new Date().toISOString(),
    spam:       false,
    reply:      null,
    ownerAlerted: false
  };

  /* 1. Spam filter */
  const spamResult = detectSpam(msgBody);
  if (spamResult.isSpam) {
    record.spam      = true;
    record.spamReason = spamResult.reason;
    store.addRecord(record);
    console.log(`[SPAM] Blocked from ${From}: ${spamResult.reason}`);
    return;
  }

  try {
    /* 2. OpenAI gpt-4o-mini — with session memory */
    const sessionHistory = store.getSession(From);
    const aiReply = await callOpenAI(ProfileName, From, msgBody, sessionHistory);
    record.reply = aiReply;

    /* 3. Update session memory */
    store.updateSession(From, msgBody, aiReply);

    /* 4. Send reply to client */
    await sendWhatsApp(From, aiReply);

    /* 5. Alert owner */
    const ownerMsg =
      `[OTF Agent] New inquiry\n` +
      `From: ${ProfileName || From} (${From})\n` +
      `Message: ${msgBody}\n` +
      `Agent replied: ${aiReply.slice(0, 200)}${aiReply.length > 200 ? '…' : ''}`;
    await sendWhatsApp(process.env.OWNER_WHATSAPP || 'whatsapp:+254106351077', ownerMsg);
    record.ownerAlerted = true;

    /* 6. Forward to Make.com for additional workflow */
    const makeUrl = process.env.MAKE_WEBHOOK_URL;
    if (makeUrl) {
      fetch(makeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ From, ProfileName, Body: msgBody, MessageSid, aiReply })
      }).catch(() => {});
    }

  } catch (err) {
    record.error = err.message;
    console.error('[Agent error]', err.message);
  }

  store.addRecord(record);
});

/* ── DASHBOARD: simulate a message (owner only via admin secret) ── */
app.post('/api/simulate', apiLimiter, async (req, res) => {
  const { message, profileName, from } = req.body;
  if (!message) return res.status(400).json({ error: 'message required' });

  const spamCheck = detectSpam(message);
  if (spamCheck.isSpam) {
    return res.json({ spam: true, reason: spamCheck.reason, reply: null });
  }

  try {
    const fromNum    = from || 'whatsapp:+254700000000';
    const sessionHistory = store.getSession(fromNum);
    const aiReply    = await callOpenAI(profileName || 'Demo User', fromNum, message, sessionHistory);
    store.updateSession(fromNum, message, aiReply);

    const record = {
      id: `sim_${Date.now()}`,
      from: fromNum,
      clientName: profileName || 'Demo User',
      message,
      timestamp: new Date().toISOString(),
      spam: false,
      reply: aiReply,
      simulated: true
    };
    store.addRecord(record);

    res.json({ spam: false, reply: aiReply, record });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ── ADMIN: get all logs (owner secret required) ── */
app.get('/api/admin/logs', adminOnly, (req, res) => {
  const limit  = Math.min(parseInt(req.query.limit) || 50, 200);
  const filter = req.query.filter; // 'spam' | 'legit' | undefined
  let logs = store.conversations;
  if (filter === 'spam')  logs = logs.filter(c => c.spam);
  if (filter === 'legit') logs = logs.filter(c => !c.spam);
  res.json({ logs: logs.slice(0, limit), stats: store.getStats() });
});

/* ── ADMIN: export logs as JSON ── */
app.get('/api/admin/export', adminOnly, (req, res) => {
  res.setHeader('Content-Disposition', `attachment; filename="otf-logs-${Date.now()}.json"`);
  res.setHeader('Content-Type', 'application/json');
  res.json({ exported: new Date().toISOString(), logs: store.conversations, stats: store.getStats() });
});

/* ── ADMIN: stats only ── */
app.get('/api/admin/stats', adminOnly, (req, res) => {
  res.json(store.getStats());
});

/* ── DASHBOARD: public stats (no keys, just counts) ── */
app.get('/api/stats/public', (req, res) => {
  const s = store.getStats();
  res.json({ total: s.total, spam: s.spam, legit: s.legit });
});

/* ── Catch-all → serve index.html (SPA) ── */
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/* ── START ── */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n✅ OTF Solutions Agent running on port ${PORT}`);
  console.log(`   OpenAI key    : ${process.env.OPENAI_API_KEY ? '✓ configured (gpt-4o-mini)' : '✗ MISSING'}`);
  console.log(`   Twilio SID    : ${process.env.TWILIO_ACCOUNT_SID ? '✓ configured' : '✗ MISSING'}`);
  console.log(`   Make webhook  : ${process.env.MAKE_WEBHOOK_URL ? '✓ configured' : '✗ MISSING'}`);
  console.log(`   Owner alert   : ${process.env.OWNER_WHATSAPP || 'whatsapp:+254106351077'}\n`);
});
